web-boilerplate
===============

boilerplate for web projects based on initializr. 

Check the wiki for instructions on how to set up the development environment
